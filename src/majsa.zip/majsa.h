#pragma once

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "main.h"
#include "Calculator.h"
#include "AgariChecker.h"
#include "YakuChecker.h"
#include "NewDef.h"
#include "Sort.h"

Result *majsa(Status *status);  // 主函数

void DelCurrentTile(Status *status, Possible *Possibles);   //去除当前牌